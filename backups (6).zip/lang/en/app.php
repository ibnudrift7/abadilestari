<?php 

return array(
		'home' => 'home',
		'about' => 'about',
		'process' => 'process',
		'facility' => 'facility',
		'contact' => 'contact',

		'back'=>'Back',

		'facility_title' => 'Our Facilities',
		'contact_title' => 'Contact Us',

		// contact form
		'Name'=>'Name',
		'Company'=>'Company',
		'Telephone'=>'Telephone',
		'Email'=>'Email',
		'Address'=>'Address',
		'Message'=>'Message',
	);


?>