<?php 

return array(
		'home' => '家',
		'about' => '关于',
		'process' => '我们的过程',
		'facility' => '我们的设施',
		'contact' => '联系',

		'back'=>'背部',

		'facility_title' => '我们的设施',
		'contact_title' => '联系我们',

		// contact form
		'Name'=>'名称',
		'Company'=>'公司',
		'Telephone'=>'电话',
		'Email'=>'电子邮件',
		'Address'=>'地址',
		'Message'=>'信息',
	);


?>